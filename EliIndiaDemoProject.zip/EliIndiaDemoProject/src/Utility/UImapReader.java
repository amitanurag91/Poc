package Utility;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;

import org.openqa.selenium.By;

public class UImapReader {
	Properties prop;
	FileInputStream fs;
	File src;
	
		public UImapReader()
		{
			try
			{
		    src= new File("./Configuration/UImap.property"); 
			fs= new FileInputStream(src);
			prop=new Properties();
			prop.load(fs);
			}	
			catch(Exception e)
			{
				System.out.println("Exception occured with message"+e.getMessage());
			}
		}
		
public By GetLocator(String elementName)
{
	String [] locatorDetails= prop.getProperty(elementName).split(":");
	String locatorType= locatorDetails[0];
	String locatorValue= locatorDetails[1];
	
	if(locatorType.equals("id"))
	{
		return By.id(locatorValue);
	}
	else if(locatorType.equals("xpath"))
	{
		return By.xpath(locatorValue);
	}
	return null;
	
	
}

}
