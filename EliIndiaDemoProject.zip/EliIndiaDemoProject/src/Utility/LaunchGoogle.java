package Utility;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class LaunchGoogle {
	 WebDriver driver;
	ConfigReader reader = new ConfigReader();
	
	public LaunchGoogle(WebDriver driver)
	{
		this.driver=driver;
	}
	
	public  WebDriver fetchGoogleHomepage()
	{
		System.setProperty("webdriver.chrome.driver",reader.getChromeDriverPath());
		driver= new ChromeDriver();
		driver.get(reader.getUrl());
		driver.manage().window().maximize();
		return driver;
		
	}

}
