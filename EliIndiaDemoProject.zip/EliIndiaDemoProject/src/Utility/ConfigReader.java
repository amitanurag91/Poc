package Utility;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;

public class ConfigReader {
	Properties prop;
	FileInputStream fs;
	File src;
	
		public ConfigReader()
		{
			try
			{
		    src= new File("./Configuration/config.property"); 
			fs= new FileInputStream(src);
			prop=new Properties();
			prop.load(fs);
			}	
			catch(Exception e)
			{
				System.out.println("Exception occured with message"+e.getMessage());
			}
		}

	public String getUrl()
	{
		return prop.getProperty("url");
	}
	public String getChromeDriverPath()
	{
		return prop.getProperty("chromePath");
	}
	
		
}
