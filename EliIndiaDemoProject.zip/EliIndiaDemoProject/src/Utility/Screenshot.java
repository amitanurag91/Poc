package Utility;

import org.openqa.selenium.WebDriver;

import com.assertthat.selenium_shutterbug.core.Shutterbug;
import com.assertthat.selenium_shutterbug.utils.web.ScrollStrategy;

public class Screenshot {

	
	public static void takeScreenshot(WebDriver driver)
	{
		Shutterbug.shootPage(driver,ScrollStrategy.BOTH_DIRECTIONS).withName("googleSearchResults").save("./Screenshot/");
	}
}
