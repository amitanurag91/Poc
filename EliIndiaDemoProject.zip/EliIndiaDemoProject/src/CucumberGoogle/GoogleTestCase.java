package CucumberGoogle;

import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import Utility.ConfigReader;

public class GoogleTestCase {
	WebDriver driver;
	ConfigReader configRead= new ConfigReader();
	
@Test
public void GoogleSearchTC()
{
	System.setProperty("webdriver.chrome.driver",configRead.getChromeDriverPath());
	driver= new ChromeDriver();
	driver.get(configRead.getUrl());
	
}

}
