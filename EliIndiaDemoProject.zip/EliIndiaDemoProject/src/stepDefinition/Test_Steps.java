package stepDefinition;

import java.io.File;

import org.apache.commons.io.FileUtils;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.assertthat.selenium_shutterbug.core.Shutterbug;
import com.assertthat.selenium_shutterbug.utils.web.ScrollStrategy;

import Utility.ConfigReader;
import Utility.LaunchGoogle;
import Utility.Screenshot;
import Utility.UImapReader;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Test_Steps {

	WebDriver driver;
   ConfigReader reader= new ConfigReader();
   UImapReader uiReader = new UImapReader();
   LaunchGoogle launchObj ;
String expctdTitle="Google";


@Given("^User is on google homepage$")
public void user_is_on_google_homepage() throws Throwable {
	launchObj= new LaunchGoogle(driver);
	this.driver= launchObj.fetchGoogleHomepage();
	System.out.println(driver.getTitle());
	Assert.assertEquals(driver.getTitle(),expctdTitle);
}

@When("^User enters \"(.*?)\" in google searchbox and press Enter$")
public void user_enters_keyword_in_google_searchbox_and_press_Enter(String keyword) throws Throwable {
   WebElement txtbox= driver.findElement(uiReader.GetLocator("googleTextBox"));
    txtbox.sendKeys(keyword);
    txtbox.sendKeys(Keys.ENTER);
    
}

@Then("^take a screenshot of the available results$")
public void take_a_screenshot_of_the_available_results() throws Throwable {
	Thread.sleep(3000);
	Screenshot.takeScreenshot(driver);
    
}

@Then("^term link should be present on the navigated page$")
public void term_link_should_be_present_on_the_navigated_page() throws Throwable {
	
	By termLinkLocator = uiReader.GetLocator("termLink");
	WebElement termLink = driver.findElement(termLinkLocator);
	WebDriverWait wait = new WebDriverWait(driver,6);
	wait.until(ExpectedConditions.presenceOfElementLocated(termLinkLocator));
Assert.assertTrue(termLink.isDisplayed());
	
}
@Then("^close the browser$")
public void close_the_browser() throws Throwable {
    driver.quit();
}

}
